
/**
 * IMPORTANT: Make sure you are using the correct package name.
 * This example uses the package name:
 * package com.example.android.justjava
 * If you get an error when copying this code into Android studio, update it to match teh package name found
 * in the project's AndroidManifest.xml file.
 **/

package net.hellobye.justjava;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {

    int quantity = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        display(quantity);
    }

    /**
     * This method is called when the order button is clicked.
     */
    public void submitOrder(View view) {

        EditText hisName = (EditText) findViewById(R.id.yourName);
        String name = hisName.getText().toString();

        CheckBox cream = (CheckBox) findViewById(R.id.checkBox);
       CheckBox chocolate = (CheckBox) findViewById(R.id.checkBox2);
       boolean iscream = cream.isChecked();
       boolean ischco = chocolate.isChecked();
//
//
//        display(summary(calculatePrice(quantity,cream.isChecked(),chocolate.isChecked()),name, cream.isChecked(),chocolate.isChecked()));

        Intent sendIntent = new Intent(Intent.ACTION_SENDTO);
        sendIntent.setData(Uri.parse("mailto:")); // Only email app handles this Intent
        sendIntent.putExtra(Intent.EXTRA_EMAIL,"Coffee@store.com");
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "New Order from Just Java Order for " + name);
        sendIntent.putExtra(Intent.EXTRA_TEXT, summary(calculatePrice(quantity,cream.isChecked(),chocolate.isChecked()),name, cream.isChecked(),chocolate.isChecked()));
        if (sendIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(sendIntent);
        }



    }

    /**
     * This method displays the given quantity value on the screen.
     */
    public void display(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }

    /**
     * This method increes the given quantity value on the screen.
     */
    public void increment(View view) {

        if (quantity ==100) {
           Toast text =   Toast.makeText(this,"You can not take above 100 cup",Toast.LENGTH_SHORT);
            text.show();
            return;
        }

        quantity = quantity + 1;
        display(quantity);
    }

    /**
     * This method decrees the given quantity value on the screen.
     */
    public void decrement(View view) {
        if (quantity ==1) {
            Toast.makeText(this,"You only must take about 1 cup",Toast.LENGTH_SHORT).show();
            return;

        }
        quantity = quantity - 1;
        display(quantity);


    }

    /**
     * Calculates the price of the order.
     *
     * @param quantity is the number of cups of coffee ordered
     */
    private int calculatePrice(int quantity, boolean cream, boolean chocolate) {

        //  PRICE FOR ONE CUP
        int basePrice = 5;

        // CHECK TO ADD CREAM
        if (cream) {
            basePrice += 1;
        }

        // CHECK TO ADD chocolate
        if (chocolate) {
            basePrice += 2;

        }
        return basePrice * quantity;
    }


    private String summary(int price, String Name,boolean iscream,boolean ischco) {

        String message =  "" + getString(R.string.order_summary_name,Name);
;        message = message + "\n" + getString(R.string.order_summary_quantity,quantity);
        message = message + "\n" + getString(R.string.order_summary_whipped_cream,iscream);
        message = message + "\n" + getString(R.string.order_summary_chocolate,ischco);
        message = message + "\n" + getString(R.string.order_summary_price,price);
        message = message + "\n" + getString(R.string.thank_you);

        return message;


    }


}